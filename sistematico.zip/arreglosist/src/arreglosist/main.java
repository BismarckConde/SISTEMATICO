package arreglosist;
import java.util.Scanner;
public class main {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		 int arreA[],arreB[] =null,n,num,prop=0;
		int proA=1,proM=1;
		double z;

		
		System.out.println(" INGRESE EL TAMAÑO DE ARREGLO");
		n=tc.nextInt();
		arreA=new int[n];
		arreB=new int[n];
		
		System.out.println(" INGRESE LOS VALORES DEL ARREGLO A");
		for (int i=0; i<n; i++)
		{
			System.out.println("ARREGLO A ");
			arreA[i]=tc.nextInt();
		}
		
		System.out.println(" INGRESE LOS VALORES DEL ARREGLO B");
		for (int i=0; i<n; i++)
		{
			System.out.println(" ARREGLO B");
			arreB[i]=tc.nextInt();
		}
		for (int i=0; i<n; i++)
		{
			prop=prop+(arreA[i]*arreB[i]);
		}
		System.out.println(" EL PRODUCTO PUNTO DE LOS VECTORES A Y  B ES : "+prop);
		
		for(int i=0;i<n; i++)
		{
			proA*=arreA[i]*arreB[i];
			proM*=Math.abs(arreA[i])* Math.abs(arreB[i]);
		}
		z=proA/proM;
		System.out.println(" EL VALOR DE LA EXPRESION Z ES : "+z);
		tc.close();
	}
}
